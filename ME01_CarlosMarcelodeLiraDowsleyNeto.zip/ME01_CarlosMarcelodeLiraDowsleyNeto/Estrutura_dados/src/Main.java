
public class Main {
    public static void main(String[] args) {
        Vetor lista = new Vetor();

        System.out.printf("Hello and welcome!");
        Aluno a1 = new Aluno();
        Aluno a2 = new Aluno();
        Aluno a3 = new Aluno();
        Aluno a4 = new Aluno();
        Aluno a5 = new Aluno();
        Aluno a6 = new Aluno();
        Aluno a7 = new Aluno();
        Aluno a8 = new Aluno();
        Aluno a9 = new Aluno();
        Aluno a10 = new Aluno();
        Aluno a11 = new Aluno();
        Aluno a12 = new Aluno();
        Aluno a13 = new Aluno();
        Aluno a14 = new Aluno();
        Aluno a15 = new Aluno();

        a1.setNome("Glevson");
        a2.setNome("Francisco");
        a3.setNome("Maria");
        a4.setNome("João");
        a5.setNome("José");
        a6.setNome("Miguel");
        a7.setNome("Marcos");
        a8.setNome("Pedro");
        a9.setNome("Marcelo");
        a10.setNome("Laura");
        a11.setNome("Ane");
        a12.setNome("Matheus");
        a13.setNome("Rodrigo");
        a14.setNome("Thays");
        a15.setNome("Igor");



        lista.Adiciona(a1);
        lista.Adiciona(a2);
        lista.Adiciona(a3);
        lista.Adiciona(a4);
        lista.Adiciona(a5);
        lista.Adiciona(a6);
        lista.Adiciona(a7);
        lista.Adiciona(a8);
        lista.Adiciona(a9);
        lista.Adiciona(a10);
        lista.Adiciona(a11);
        lista.Adiciona(a12);
        lista.Adiciona(a13);

        System.out.println("\nTotal de alunos: " +lista.getTotalDealunos());

        System.out.println(lista);

        System.out.println("1) Removendo os alunos: ");
        lista.remove(1);
        lista.remove(3);

        System.out.println("Total de alunos: " +lista.getTotalDealunos());
        System.out.println(lista);

        System.out.println("2) Adicionando os alunos na posição: ");
        lista.adicionaPosicao(1, a14);
        lista.adicionaPosicao(3, a15);

        System.out.println("Total de alunos: " +lista.getTotalDealunos());
        System.out.println(lista);




    }
}