package tabelas_de_espalhamento;

import java.util.List;

public class TesteTamanho {
	public static void main(String[] args) {
		ConjuntoEspalhamento conjunto = new ConjuntoEspalhamento();
		conjunto.adiciona("Marcelo");
		conjunto.adiciona("Letícia");
		conjunto.adiciona("Marcelo");
		conjunto.adiciona("Glevson");
		conjunto.adiciona("Alexandre");
		List<String> palavras = conjunto.pegaTodas();
		
		System.out.println("Lista de nomes no conjunto:");
		for (String palavra : palavras) {
			System.out.println(palavra);
		}
		System.out.println("");
		System.out.println("Tamanho do conjunto: " + conjunto.getTamanho());
	}
}
