package tabelas_de_espalhamento;

import java.util.List;

public class TesteContem {
	public static void main(String[] args) {
		ConjuntoEspalhamento conjunto = new ConjuntoEspalhamento();
		conjunto.adiciona("Marcelo");
		conjunto.adiciona("Letícia");
		conjunto.adiciona("Leonardo");
		conjunto.adiciona("Glevson");
		conjunto.adiciona("Alexandre");
		List<String> palavras = conjunto.pegaTodas();
		System.out.println("Nomes no conjunto:");
		for (String palavra : palavras) {
			System.out.println(palavra);
		}
		
		System.out.println("");
		
		System.out.println("Testando se ele devolve o contem: ");
		for (String palavra : palavras) {
			System.out.println(palavra + ": " + conjunto.contem(palavra));
		}
		System.out.println("");
		System.out.println("Testando se ele devolve o contem para uma palavra não adicionada: ");
		System.out.println("Lúcia: " + conjunto.contem("Lúcia"));
	}
	
}
