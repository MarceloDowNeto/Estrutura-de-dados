package tabelas_de_espalhamento;

public class TesteConjuntoGenerico {
	public static void main(String[] args) {
		ConjuntoEspalhamentoGenerico<String> conjunto = new ConjuntoEspalhamentoGenerico<String>();
		conjunto.adiciona("Rafael");
		conjunto.adiciona("Rafael");
		conjunto.adiciona("Ana");
		conjunto.adiciona("Paulo");
		
		System.out.println(conjunto.pegaTodos());
		}

}
